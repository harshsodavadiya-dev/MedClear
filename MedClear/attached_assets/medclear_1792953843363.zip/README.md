# MedClear

Doctor's notes and lab results, rewritten in plain English.

## The problem
Patient portals and visit summaries are full of words most people have never seen
("tachycardia", "bilateral lower extremity edema"). Results often show up before
anyone explains them, and not understanding your own health information leads to
missed follow-ups and medicine mistakes. MedClear turns a pasted note into plain English.

## The five pages
| Page | What it does |
|---|---|
| **Translate** (`/`) | Paste text. Get a plain-English rewrite, highlighted terms, a card for every term, lab numbers compared with typical ranges, a breakdown of unfamiliar words, questions to ask your doctor, and a reading-level estimate. Copy and print buttons. |
| **Glossary** (`/glossary`) | Search and filter every term MedClear knows. |
| **Lab guide** (`/labs`) | What common tests measure, typical adult ranges, a blood pressure chart, and a "check a number" tool. |
| **Word decoder** (`/words`) | Type a medical word and see its prefix, root, and suffix. Includes a searchable table of word parts. |
| **About** (`/about`) | The problem, how it works, sources, privacy, and limits. |

Also: a "Larger text" button that remembers your choice, a tab bar that works like an
app on phones, and a lookup box that searches MedlinePlus.

## Project layout
```
medclear/
├── app.py                 Flask routes: five pages and the JSON endpoints
├── engine.py              Finds terms and phrases, builds the rewrite, glossary search
├── labs.py                Finds lab numbers, compares them with typical ranges, lab guide
├── wordparts.py           Splits medical words into prefix, root, and suffix
├── readability.py         Flesch-Kincaid grade estimate
├── lookup.py              Live lookup on MedlinePlus
├── import_medlineplus.py  Optional: builds a bigger glossary from MedlinePlus's download
├── build_terms.py         Where terms and phrases are written; builds the JSON files
├── terms.json             (generated) the glossary
├── phrases.json           (generated) doctor-phrase simplifications
├── requirements.txt
├── templates/             base.html, index.html, glossary.html, labs.html, words.html, about.html, 404.html
└── static/                style.css, common.js, script.js, glossary.js, labs.js, words.js
```
The code has no comments on purpose, so this README is the guide.

## How one request flows
You click "Translate it" -> `script.js` sends the text to `/analyze` in `app.py` ->
`engine.analyze()` runs -> JSON comes back -> `script.js` builds each section of the page.

## Safety rules in the rewrite
- Named diagnoses keep their name in the plain version, for example "cancer (carcinoma)" and
  "irregular heartbeat (atrial fibrillation)", so the real diagnosis never disappears.
- The abbreviation IV is skipped when it follows stage, grade, type, class, phase, group, factor, level, tier,
  category, or NYHA (including "Stage III/IV").

## The key ideas
**engine.py**
- Every term and phrase becomes a regular expression. `\b` (word boundary) stops "acute"
  from matching inside a longer word.
- When two matches overlap, the longest one wins. All matches are sorted by length, and any
  that overlap one already taken get skipped. That's how "acute appendicitis" beats "acute".
- Abbreviations (CBC, BP, CT) are case-sensitive so ordinary lowercase words aren't flagged.
- The rewrite swaps each match for its short plain wording, capitalizes it at the start of a
  sentence, and fixes "a" vs "an" in front of the swap.

**labs.py**
- A regex finds a lab name, optional glue ("is", ":", "="), then a number.
- Numbers are cleaned up (11,500 becomes 11.5) and thrown out if they're not plausible.
- Blood pressure is parsed on its own (two numbers) and sorted into AHA categories.
- It only says below, within, or above a typical range. It never diagnoses.

**wordparts.py**
- It tries to cover the whole word with known parts, allowing a connecting vowel like the "o"
  in cardi-o-myo-pathy. If it can't cover every letter, it says nothing instead of guessing.
- When MedClear scans a note for unknown words it uses a strict mode: a word needs at least two meaningful parts
  (not just a root plus a generic ending like -al), which keeps words like "colonial" and "postal" from being flagged.
- It uses recursion with memoization (`lru_cache`) to find the split with the fewest parts.

**readability.py**
- Flesch-Kincaid: `0.39 * (words / sentences) + 11.8 * (syllables / words) - 15.59`.
- Only scored for text with 2+ sentences and capped at 18, because one huge sentence of long
  Latin words makes the formula give meaningless numbers.

## Technical challenge I solved (rewrite this in your own words for the form)
Overlapping matches. Medical terms contain smaller terms ("atrial fibrillation"), and doctor
phrases overlap terms ("no acute distress" contains "acute"). My first version flagged both
pieces and produced a garbled rewrite. I fixed it by collecting every possible match, sorting
by length, and keeping the longest match at each spot.

## Running it
Replit: put the files in the project, run `pip install -r requirements.txt` in the Shell, then
`python app.py`.
Locally: `pip install -r requirements.txt`, `python app.py`, open http://localhost:5000

## Adding terms
1. Add a line to `TERMS` in `build_terms.py`. Each entry is
   `(term, meaning, analogy, category, is_abbreviation, short_swap)`.
2. Check the meaning against MedlinePlus.
3. Run `python build_terms.py` and restart the app.

## Growing the glossary with MedlinePlus (optional)
1. Download "MedlinePlus Compressed Health Topic XML" (a .zip) from https://medlineplus.gov/xml.html
   and upload it to the project.
2. Run `python import_medlineplus.py <file name>`. It writes `medlineplus_terms.json`.
3. Restart the app. Imported terms show up in the rewrite, the term cards, and the glossary
   page, each credited to MedlinePlus.gov. Hand-written terms always win over imported ones.

## Verification checklist (do this before you submit)
- [ ] Every glossary definition checked against MedlinePlus (medlineplus.gov)
- [ ] Every typical range in `labs.py` checked against MedlinePlus lab-test pages or another
      reliable source. Sources used: ____________
      (Creatinine is already matched to MedlinePlus: 0.7 to 1.3 mg/dL for men, 0.6 to 1.1 mg/dL for women.)
- [ ] Blood pressure categories checked against the American Heart Association chart
- [ ] Word-part meanings in `wordparts.py` checked against a medical terminology reference
- [ ] Lookup tested live on Replit (it needs internet)
- [ ] If you ran the MedlinePlus import: spot-check 10 imported entries

## Known limits
- Some glossary words are also ordinary English ("lateral", "progressive", "topical", "transient"), so they
  highlight in non-medical text too. MedClear is built for medical text.
- Lab abbreviations like HR, Na, TG, and PLT only count in capital letters, so "2 hr 30 min" isn't read as a
  heart rate. The cost is that a lowercase "hr 72" is missed; "heart rate 72" works.
- Roman numerals in "Stage IV", "Grade IV", and "NYHA class IV" are not treated as the abbreviation IV (intravenous).
- It only knows the terms in its glossary, plus what the word decoder and lookup can work out.
- The rewrite swaps words, so the grammar can be stiff.
- Typical ranges don't account for age, sex, or health history.
- Reading-level scores are estimates.

## Future ideas
Photo scanning (OCR), more languages, saving results privately, age- and sex-specific ranges,
smoother rewriting.

## Sources and credits
- MedlinePlus.gov, National Library of Medicine (lookup and optional imported glossary).
  MedlinePlus doesn't endorse this app.
- American Heart Association blood pressure categories.
- Flask (Python web framework).

## AI assistance disclosure (required by CAC) - fill this in honestly
- Claude (Anthropic) helped write the starting code, the first draft of the glossary, phrase
  list, lab ranges, word-part list, and site design.
- Replit's AI Agent restored a layout file and set up the app's start-up in Replit.
- What I checked, tested, changed, or wrote myself: ____________
